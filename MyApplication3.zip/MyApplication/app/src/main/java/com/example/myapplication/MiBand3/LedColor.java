package com.example.myapplication.MiBand3;


public enum LedColor {
    RED, BLUE, ORANGE, GREEN,
}
