package com.example.myapplication.MiBand3;

public interface NotifyListener {
    public void onNotify(byte[] data);
}
