package com.example.myapplication.MiBand3;

public interface RealtimeStepsNotifyListener {
    public void onNotify(int steps);
}
